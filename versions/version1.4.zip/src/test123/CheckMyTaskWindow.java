package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CheckMyTaskWindow extends JFrame {
    private String accountId;
    private JPanel taskListPanel;

    public CheckMyTaskWindow(String accountId) {
        this.accountId = accountId;
        setTitle("My Tasks");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        JLabel promptLabel = new JLabel("Your current task is shown below");
        promptLabel.setHorizontalAlignment(SwingConstants.CENTER);
        promptLabel.setVerticalAlignment(SwingConstants.CENTER);
        mainPanel.add(promptLabel, BorderLayout.NORTH);

        taskListPanel = new JPanel();
        taskListPanel.setLayout(new BoxLayout(taskListPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(taskListPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        displayTasks(accountId);

        add(mainPanel);
    }

    private void displayTasks(String accountId) {
        taskListPanel.removeAll();

        List<String> tasks = readTasksFromFile();

        boolean foundTasks = false;
        for (String task : tasks) {
            String[] taskInfo = task.split("\n");
            if (taskInfo.length == 5 && taskInfo[0].equals(accountId)) {
                foundTasks = true;
                JButton taskButton = new JButton();
                taskButton.setPreferredSize(new Dimension(taskListPanel.getWidth(), getHeight() / 4));
                StringBuilder buttonText = new StringBuilder();
                buttonText.append("<html>");
                buttonText.append("<b>Task ID:</b> ").append(taskInfo[1]).append("<br>");
                buttonText.append("<b>Award:</b> ").append(taskInfo[2]).append("<br>");
                buttonText.append("<b>Task Name:</b> ").append(taskInfo[3]).append("<br>");
                buttonText.append("<b>Time Limit:</b> ").append(taskInfo[4]);
                buttonText.append("</html>");
                taskButton.setText(buttonText.toString());
                taskButton.addActionListener(e -> {
                    String message = "The remaining days for this task is " + taskInfo[4] ;
                    String title = "Task Remaining Time";
                    int choice = JOptionPane.showOptionDialog(
                            CheckMyTaskWindow.this,
                            message,
                            title,
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                            null,
                            new Object[]{"Yes"},
                            "Yes"
                    );

                });
                taskListPanel.add(taskButton);
            }
        }

        if (!foundTasks) {
            JLabel noTasksLabel = new JLabel("You have no tasks.");
            taskListPanel.add(noTasksLabel);
        }

        revalidate();
        repaint();
    }

    private List<String> readTasksFromFile() {
        List<String> tasks = new ArrayList<>();
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader("D:/test123/taskInfo.txt"))) {
            StringBuilder taskBuilder = new StringBuilder();
            while ((line = br.readLine()) != null) {
                taskBuilder.append(line).append("\n");
                if (line.endsWith(";")) {
                    tasks.add(taskBuilder.toString());
                    taskBuilder = new StringBuilder();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tasks;
    }





    public static void main(String[] args) {
        CheckMyTaskWindow checkMyTaskWindow = new CheckMyTaskWindow("accountId");
        SwingUtilities.invokeLater(() -> checkMyTaskWindow.setVisible(true));
    }
}
