package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DepositFromCurrent extends JFrame {
    private JButton depositButton;
    private JTextField amountTextField;
    private String currentAccountId;
    private String savingAccountId;

    public DepositFromCurrent(String currentAccountId, String savingAccountId) {
        this.currentAccountId = currentAccountId;
        this.savingAccountId = savingAccountId;
        setTitle("Deposit to Saving Account");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        amountTextField = new JTextField(10);
        depositButton = new JButton("Deposit");
        JLabel amountLabel = new JLabel("Amount:");

        inputPanel.add(amountLabel);
        inputPanel.add(amountTextField);
        inputPanel.add(depositButton);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        depositButton.addActionListener(e -> depositToSavingAccount());

        add(mainPanel);
    }

    private void depositToSavingAccount() {
        double amount = Double.parseDouble(amountTextField.getText());

        // Deduct amount from current account
        updateCurrentAccountBalance(amount);

        // Increase amount in saving account
        updateSavingAccountBalance(amount);

        JOptionPane.showMessageDialog(this, "Deposit Successful!");
        dispose();
    }

    private void updateCurrentAccountBalance(double amount) {
        List<String> currentInfoLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/currentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(currentAccountId)) {
                    double currentBalance = Double.parseDouble(parts[1]);
                    currentBalance -= amount; // Deduct amount from current balance
                    currentInfoLines.add(parts[0] + "," + currentBalance);
                } else {
                    currentInfoLines.add(line);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Write the updated current info to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/currentInfo.txt"))) {
            for (String line : currentInfoLines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void updateSavingAccountBalance(double amount) {
        List<String> savingInfoLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/savingInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(savingAccountId)) {
                    double currentBalance = Double.parseDouble(parts[1]);
                    currentBalance += amount; // Increase amount in saving balance
                    savingInfoLines.add(parts[0] + "," + currentBalance );
                } else {
                    savingInfoLines.add(line);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Write the updated saving info to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/savingInfo.txt"))) {
            for (String line : savingInfoLines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DepositFromCurrent("currentAccountId", "savingAccountId").setVisible(true);
        });
    }
}
