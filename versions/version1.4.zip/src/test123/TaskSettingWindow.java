package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class TaskSettingWindow extends JFrame {
    private JTextField taskIdField, awardField, taskNameField, timeLimitField;
    private String parentId;
    private JTextField selectedChildField;

    public TaskSettingWindow(String parentId) {
        this.parentId = parentId;
        setTitle("Task Setting Window");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridLayout(7, 1));

        JLabel infoLabel = new JLabel("Please set some details of the task to your child", SwingConstants.CENTER);
        mainPanel.add(infoLabel);

        taskIdField = new JTextField(15);
        JPanel taskIdPanel = createInputPanel("Task ID:", taskIdField);
        mainPanel.add(taskIdPanel);

        awardField = new JTextField(15);
        JPanel awardPanel = createInputPanel("Award:", awardField);
        mainPanel.add(awardPanel);

        taskNameField = new JTextField(15);
        JPanel taskNamePanel = createInputPanel("Task Name:", taskNameField);
        mainPanel.add(taskNamePanel);

        timeLimitField = new JTextField(15);
        JPanel timeLimitPanel = createInputPanel("Time Limit:", timeLimitField);
        mainPanel.add(timeLimitPanel);

        JPanel selectChildPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton selectChildButton = new JButton("Select Your Child");
        selectedChildField = new JTextField(10);
        selectedChildField.setEditable(false); // Disable editing
        selectChildPanel.add(selectChildButton);
        selectChildPanel.add(selectedChildField);
        mainPanel.add(selectChildPanel);

        selectChildButton.addActionListener(e -> {
            TaskSelectionWindow selectionWindow = new TaskSelectionWindow(parentId);
            selectionWindow.setVisible(true);
            selectionWindow.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                    String selectedChildId = selectionWindow.getSelectedChildId();
                    if (selectedChildId != null) {
                        selectedChildField.setText(selectedChildId);
                    }
                }
            });
        });

        JButton confirmButton = new JButton("Confirm");
        confirmButton.addActionListener(e -> confirmTaskSetting());
        mainPanel.add(confirmButton);

        add(mainPanel);
    }

    private JPanel createInputPanel(String labelText, JTextField textField) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel label = new JLabel(labelText);
        textField.setHorizontalAlignment(JTextField.LEFT); // Align text to the left
        panel.add(label);
        panel.add(textField);
        return panel;
    }

    private void confirmTaskSetting() {
        // Check if all fields are provided
        if (taskIdField == null || awardField == null || taskNameField == null || timeLimitField == null || selectedChildField == null) {
            JOptionPane.showMessageDialog(this, "Internal error: Text fields are not properly initialized.");
            return;
        }

        String taskId = taskIdField.getText();
        String award = awardField.getText();
        String taskName = taskNameField.getText();
        String timeLimit = timeLimitField.getText();
        String selectedChildId = selectedChildField.getText();

        // Check if any text field is empty
        if (taskId.isEmpty() || award.isEmpty() || taskName.isEmpty() || timeLimit.isEmpty() || selectedChildId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and select a child.");
            return;
        }

        // Check if task ID is unique
        if (!isTaskIdUnique(taskId)) {
            JOptionPane.showMessageDialog(this, "Task ID already exists. Please use a different ID.");
            return;
        }



        // Check if task name is valid
        if (!isTaskNameValid(taskName)) {
            JOptionPane.showMessageDialog(this, "Task name contains invalid characters.");
            return;
        }

        // 验证任务奖励是否合法
        if (!isAwardValid(award)) {
            JOptionPane.showMessageDialog(this, "Award must be a number.");
            return;
        }

        // 验证任务期限是否合法
        if (!isTimeLimitValid(timeLimit)) {
            JOptionPane.showMessageDialog(this, "Time limit must be an integer.");
            return;
        }

        // Write task setting information to a file
        writeTaskInfo(selectedChildId, taskId, award, taskName, timeLimit);

        // Close the window after confirming
        dispose();
    }


    private boolean isTaskIdUnique(String taskId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/taskInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Compare the taskId with each line read
                if (line.equals("#" + taskId)) {
                    return false; // Task ID already exists
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return true; // Task ID is unique
    }

    private boolean isTaskNameValid(String taskName) {
        return taskName.matches("[a-zA-Z0-9 ]*"); // Only allow letters, digits, and spaces
    }
    // 任务奖励只能是数字
    private boolean isAwardValid(String award) {
        return award.matches("\\d+(\\.\\d+)?"); // Allow integers and decimals
    }

    // 任务期限只能是整数
    private boolean isTimeLimitValid(String timeLimit) {
        return timeLimit.matches("\\d+"); // Only allow digits
    }


    private void writeTaskInfo(String selectedChildId, String taskId, String award, String taskName, String timeLimit) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/taskInfo.txt", true))) {
            writer.write(selectedChildId);
            writer.newLine();
            writer.write("#" + taskId); // Add # prefix to the task ID
            writer.newLine();
            writer.write(award);
            writer.newLine();
            writer.write(taskName);
            writer.newLine();
            writer.write(timeLimit);
            writer.write(";");
            writer.newLine();
            JOptionPane.showMessageDialog(this, "Task Setting Successful!");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TaskSettingWindow("parentId").setVisible(true));
    }
}
