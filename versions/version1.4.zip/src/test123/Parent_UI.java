package test123;

import javax.swing.*;
import java.awt.*;

public class Parent_UI extends JFrame {
    private String accountId;
    private JButton bindingButton;
    private JButton setTaskButton;
    private JButton tasksOfChildButton;

    public Parent_UI(String accountId) {
        this.accountId = accountId;
        setTitle("Parent Account Page");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridLayout(3, 1, 0, 10)); // 3 rows, 1 column, vertical gap of 10 pixels

        bindingButton = new JButton("Binding");
        setTaskButton = new JButton("SetTask");
        tasksOfChildButton = new JButton("Tasks of Child");

        bindingButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        setTaskButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        tasksOfChildButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        bindingButton.addActionListener(e -> {
            new BindingWindow(accountId).setVisible(true);
        });

        setTaskButton.addActionListener(e -> {
            new TaskSettingWindow(accountId).setVisible(true);
        });

        tasksOfChildButton.addActionListener(e -> {
            // Open TaskSelectionWindow
            TaskSelectionWindow selectionWindow = new TaskSelectionWindow(accountId);
            selectionWindow.setVisible(true);
            selectionWindow.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent windowEvent) {
                    String selectedChildId = selectionWindow.getSelectedChildId();
                    if (selectedChildId != null) {
                        // Open TaskOfChild window with selected child ID
                        new TaskOfChild(selectedChildId).setVisible(true);
                    }
                }
            });
        });

        mainPanel.add(bindingButton);
        mainPanel.add(setTaskButton);
        mainPanel.add(tasksOfChildButton);

        add(mainPanel);
    }

    public static void displayUI(String accountId) {
        java.awt.EventQueue.invokeLater(() -> new Parent_UI(accountId).setVisible(true));
    }
}
