package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class WithdrawFromCurrent extends JFrame {
    private JButton withdrawButton;
    private JTextField amountTextField;
    private String currentAccountId;

    public WithdrawFromCurrent(String currentAccountId) {
        this.currentAccountId = currentAccountId;
        setTitle("Withdraw from Current Account");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        amountTextField = new JTextField(10);
        withdrawButton = new JButton("Withdraw");
        JLabel amountLabel = new JLabel("Amount:");

        inputPanel.add(amountLabel);
        inputPanel.add(amountTextField);
        inputPanel.add(withdrawButton);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        withdrawButton.addActionListener(e -> withdrawFromCurrentAccount());

        add(mainPanel);
    }

    private void withdrawFromCurrentAccount() {
        double amount;
        try {
            amount = Double.parseDouble(amountTextField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (amount <= 0) {
            JOptionPane.showMessageDialog(this, "Please enter a positive amount.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double currentBalance = getCurrentAccountBalance();
        if (currentBalance < amount) {
            JOptionPane.showMessageDialog(this, "Insufficient funds.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        updateCurrentAccountBalance(amount);
        JOptionPane.showMessageDialog(this, "Withdrawal Successful!");
        dispose();
    }

    private double getCurrentAccountBalance() {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/currentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] accountInfo = line.split(",");
                if (accountInfo[0].equals(currentAccountId)) {
                    return Double.parseDouble(accountInfo[1]);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return 0.0;
    }

    private void updateCurrentAccountBalance(double amount) {
        List<String> currentInfoLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/currentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(currentAccountId)) {
                    double currentBalance = Double.parseDouble(parts[1]);
                    currentBalance -= amount; // Deduct amount from current balance
                    currentInfoLines.add(parts[0] + "," + currentBalance);
                } else {
                    currentInfoLines.add(line);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // Write the updated current info to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/currentInfo.txt"))) {
            for (String line : currentInfoLines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new WithdrawFromCurrent("currentAccountId").setVisible(true);
        });
    }
}
