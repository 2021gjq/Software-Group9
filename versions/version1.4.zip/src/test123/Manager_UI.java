package test123;
import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Manager_UI {

    public static void main(String[] args) {
        // 显示主界面
        displayUI();
    }

    static void displayUI() {
        // 提供创建Manager账户和修改账户信息的选项
        Object[] options = {"Create Manager Account", "View Deposit Records", "Update Manager Account"};
        int choice = JOptionPane.showOptionDialog(null, "Please select an action:", "Select Action",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == JOptionPane.YES_OPTION) {
            createManagerAccount(); // 调用创建Manager账户的方法
        } else if (choice == JOptionPane.NO_OPTION) {
            String accountID = JOptionPane.showInputDialog("Please enter the accountID to search:");
            if (accountID != null && !accountID.trim().isEmpty()) {
                readSavingInfo(accountID); // 调用查看存款记录的方法
            } else {
                JOptionPane.showMessageDialog(null, "The Account ID cannot be empty.");
            }
        } else if (choice == JOptionPane.CANCEL_OPTION) {
            updateManagerAccount(); // 调用修改Manager账户的方法
        }
    }

    private static void createManagerAccount() {
        String accountID = JOptionPane.showInputDialog("Enter new account ID for Manager:");
        if (accountID != null && !accountID.trim().isEmpty()) {
            String password = JOptionPane.showInputDialog("Enter new password for Manager:");
            if (password != null && !password.trim().isEmpty()) {
                // 将新创建的Manager账户信息存储到account.txt
                File file = new File("G:/JAVA/test123/account.txt");
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                    writer.write(accountID + "," + password + ",Manager");
                    writer.newLine();
                    JOptionPane.showMessageDialog(null, "Manager account created successfully.");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(null, "Password cannot be empty.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Account ID cannot be empty.");
        }
    }

    public static void readSavingInfo(String accountID) {
        List<String> savingInfo = new ArrayList<>();
        File file = new File("D:/test123/savingInfo.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2 && parts[0].equals(accountID)) {
                    double amount = Double.parseDouble(parts[1]);
                    String formattedAmount = String.format("%.1f", amount);
                    savingInfo.add("ID: " + parts[0] + ", Amount: " + formattedAmount);
                }
            }

            if (savingInfo.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No corresponding billing history was found.");
            } else {
                StringBuilder history = new StringBuilder();
                for (String record : savingInfo) {
                    history.append(record).append("\n");
                }
                JOptionPane.showMessageDialog(null, new JScrollPane(new JTextArea(history.toString(), 10, 30)), "Account deposit records", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void updateManagerAccount() {
        String accountID = JOptionPane.showInputDialog("Enter the account ID of the Manager to update:");
        if (accountID != null && !accountID.trim().isEmpty()) {
            // 读取account.txt文件并查找对应的Manager账户
            File file = new File("G:/JAVA/test123/account.txt");
            List<String> accountLines = new ArrayList<>();
            boolean found = false;
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3 && parts[0].equals(accountID)) {
                        if (!parts[2].equals("Manager")) {
                            JOptionPane.showMessageDialog(null, "Please fill in the ID of the manager account type");
                            return; // 如果账户类型不是manager，提醒用户并退出
                        }
                        found = true;
                        String newAccountID = JOptionPane.showInputDialog("Enter new account ID for Manager:");
                        if (newAccountID != null && !newAccountID.trim().isEmpty()) {
                            // 然后修改密码
                            String newPassword = JOptionPane.showInputDialog("Enter new password for Manager:");
                            if (newPassword != null && !newPassword.trim().isEmpty()) {
                                // 更新account.txt文件中的account_ID与password
                                accountLines.add(newAccountID + "," + newPassword + ",Manager");
                            } else {
                                JOptionPane.showMessageDialog(null, "Password cannot be empty.");
                                return; // 如果密码为空，提醒用户并退出
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "New Account ID cannot be empty.");
                            return; // 如果新账户ID为空，提醒用户并退出
                        }
                    } else {
                        accountLines.add(line);
                    }
                }
                if (!found) {
                    JOptionPane.showMessageDialog(null, "Manager account ID not found.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 将更新后的账户信息写回account.txt文件
            if (found) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
                    for (String outputLine : accountLines) {
                        writer.write(outputLine);
                        writer.newLine();
                    }
                    JOptionPane.showMessageDialog(null, "Manager account updated successfully.");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Account ID cannot be empty.");
        }
    }
}
