package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class BindingWindow extends JFrame {
    private JTextField childIdField, childPasswordField;
    private String parentId;

    public BindingWindow(String parentId) {
        this.parentId = parentId;
        setTitle("Binding Window");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridLayout(5, 1));

        JLabel infoLabel = new JLabel("Please link your child's current account", SwingConstants.CENTER);

        JPanel idPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel childIdLabel = new JLabel("ID:");
        childIdField = new JTextField(15);
        idPanel.add(childIdLabel);
        idPanel.add(childIdField);

        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel childPasswordLabel = new JLabel("Password:");
        childPasswordField = new JTextField(15);
        passwordPanel.add(childPasswordLabel);
        passwordPanel.add(childPasswordField);

        JButton confirmButton = new JButton("Confirm");

        mainPanel.add(infoLabel);
        mainPanel.add(idPanel);
        mainPanel.add(passwordPanel);
        mainPanel.add(new JPanel()); // Empty panel for spacing
        mainPanel.add(confirmButton);

        confirmButton.addActionListener(e -> confirmBinding());

        add(mainPanel);
    }

    private void confirmBinding() {
        String childId = childIdField.getText();
        String childPassword = childPasswordField.getText();

        // Check if child ID and password are provided
        if (childId.isEmpty() || childPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Child ID and Password.");
            return;
        }

        // Check if parentInfo.txt contains parent's binding information
        boolean isDuplicate = checkDuplicateBinding(parentId, childId);

        // Write parent-child binding information to parentInfo.txt
        writeParentInfo(parentId, childId, isDuplicate);


    }

    private boolean checkDuplicateBinding(String parentId, String childId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/parentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(parentId + ":")) {
                    // Parent's binding information found, check for duplicates
                    String[] bindings = line.substring(parentId.length() + 1).split(",");
                    for (String binding : bindings) {
                        if (binding.equals(childId)) {
                            JOptionPane.showMessageDialog(this, "This binding already exists.");
                            return true;
                        }
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }


    private void writeParentInfo(String parentId, String childId, boolean isDuplicate) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/parentInfo.txt", true))) {
            if (!isDuplicate) {
                if (isParentBound(parentId)) {
                    writer.newLine();
                }
                writer.write(parentId + ":" + childId);
                JOptionPane.showMessageDialog(this, "Binding Successful!");
                dispose();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private boolean isParentBound(String parentId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/parentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(parentId + ":")) {
                    return true;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BindingWindow("parentAccountId").setVisible(true));
    }
}
