package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Current_UI extends JFrame {
    private JButton backButton, myTaskButton, depositButton, withdrawButton, checkMyTaskButton; // 新添加的 checkMyTaskButton
    private String accountId;

    public Current_UI(String accountId) {
        this.accountId = accountId;
        setTitle("Current Account Page");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        JPanel balancePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        backButton = new JButton("Back");
        myTaskButton = new JButton("My Task");
        depositButton = new JButton("Transfer");
        withdrawButton = new JButton("Withdraw"); // 新添加的 withdrawButton
        checkMyTaskButton = new JButton("Check My Task"); // 新添加的 checkMyTaskButton

        backButton.setPreferredSize(new Dimension(150, 50));
        myTaskButton.setPreferredSize(new Dimension(150, 50));
        depositButton.setPreferredSize(new Dimension(150, 50));
        withdrawButton.setPreferredSize(new Dimension(150, 50)); // 设置 withdrawButton 大小
        checkMyTaskButton.setPreferredSize(new Dimension(150, 50)); // 设置 checkMyTaskButton 大小

        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        myTaskButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        depositButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        withdrawButton.setAlignmentX(Component.CENTER_ALIGNMENT); // 设置 withdrawButton 居中显示
        checkMyTaskButton.setAlignmentX(Component.CENTER_ALIGNMENT); // 设置 checkMyTaskButton 居中显示

        balancePanel.add(new JLabel("Balance: $" + getAccountBalance(accountId)));

        buttonPanel.add(backButton);
        buttonPanel.add(myTaskButton);
        buttonPanel.add(depositButton);
        buttonPanel.add(withdrawButton); // 添加 withdrawButton 到按钮面板
        buttonPanel.add(checkMyTaskButton); // 添加 checkMyTaskButton 到按钮面板

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        mainPanel.add(balancePanel, BorderLayout.NORTH);

        backButton.addActionListener(e -> {
            dispose();

        });

        myTaskButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "My Task Button Clicked!");
        });

        depositButton.addActionListener(e -> {
            new SavingInfoWindow(accountId).setVisible(true); // 显示 DepositFromCurrent 窗口
        });

        withdrawButton.addActionListener(e -> {
            new WithdrawFromCurrent(accountId).setVisible(true); // 显示 WithdrawFromCurrent 窗口
        });

        checkMyTaskButton.addActionListener(e -> {
            new CheckMyTaskWindow(accountId).setVisible(true); // 显示 CheckMyTaskWindow 窗口
        });

        add(mainPanel);
    }

    private double getAccountBalance(String accountId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/currentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] accountInfo = line.split(",");
                if (accountInfo[0].equals(accountId)) {
                    return Double.parseDouble(accountInfo[1]);
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return 0.0;
    }

    public static void displayUI(String accountId) {
        java.awt.EventQueue.invokeLater(() -> new Current_UI(accountId).setVisible(true));
    }
}
