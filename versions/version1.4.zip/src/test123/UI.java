package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class UI extends JFrame {
    private JButton loginButton, registerButton;
    private JPanel mainPanel;

    public UI() {
        setTitle("Bank Simulation System");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        mainPanel = new JPanel();
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");

        mainPanel.add(loginButton);
        mainPanel.add(registerButton);
        add(mainPanel);

        loginButton.addActionListener(e -> createLoginDialog());
        registerButton.addActionListener(e -> createRegisterDialog());
    }

    private void createLoginDialog() {
        JDialog loginDialog = new JDialog(this, "Login", true);
        loginDialog.setLayout(new GridLayout(3, 2));
        loginDialog.setSize(300, 150);
        loginDialog.setLocationRelativeTo(this);

        JTextField userIdField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(e -> {
            String userId = userIdField.getText();
            String password = new String(passwordField.getPassword());
            String username = checkCredentials(userId, password);
            if (username != null) {
                // Show login message only after successful login and before UI display
                JOptionPane.showMessageDialog(this, "Account login!");
                displayUserUI(username); // display the appropriate user interface
                loginDialog.dispose(); // Close the login dialog after successful login
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials.");
            }
        });

        loginDialog.add(new JLabel("User ID:"));
        loginDialog.add(userIdField);
        loginDialog.add(new JLabel("Password:"));
        loginDialog.add(passwordField);
        loginDialog.add(new JLabel(""));
        loginDialog.add(loginButton);

        loginDialog.setVisible(true);
    }



    private String checkCredentials(String userId, String password) {
        // Read the account.txt file and check credentials
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/account.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials[0].equals(userId) && credentials[1].equals(password)) {
                    return credentials[0]; // 返回用户名
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private void displayUserUI(String username) {
        String accountType = getAccountType(username);
        if (accountType == null) {
            JOptionPane.showMessageDialog(this, "Account type not found.");
            return;
        }
        switch (accountType) {
            case "Manager":
                Manager_UI.displayUI();
                break;
            case "Parent":
                Parent_UI.displayUI(username);
                break;
            case "Saving":
                Saving_UI.displayUI(username);
                break;
            case "Current":
                Current_UI.displayUI(username); // display the appropriate user interface
                break;
            default:
                JOptionPane.showMessageDialog(this, "Unknown account type");
        }
    }


    private String getAccountType(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/account.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials[0].equals(username)) {
                    return credentials[2]; // 返回账户类型
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private void createRegisterDialog() {
        JDialog registerDialog = new JDialog(this, "Register", true);
        registerDialog.setLayout(new GridLayout(4, 2));
        registerDialog.setSize(300, 200);
        registerDialog.setLocationRelativeTo(this);

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JRadioButton savingAccount = new JRadioButton("Saving Account");
        JRadioButton currentAccount = new JRadioButton("Current Account");
        ButtonGroup accountTypeGroup = new ButtonGroup();
        accountTypeGroup.add(savingAccount);
        accountTypeGroup.add(currentAccount);
        JButton registerButton = new JButton("Register");

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String accountType = savingAccount.isSelected() ? "Saving" : "Current";
            saveAccountInfo(username, password, accountType);
            JOptionPane.showMessageDialog(this, "Account registered successfully!");
            registerDialog.dispose();
        });

        registerDialog.add(new JLabel("Username:"));
        registerDialog.add(usernameField);
        registerDialog.add(new JLabel("Password:"));
        registerDialog.add(passwordField);
        registerDialog.add(savingAccount);
        registerDialog.add(currentAccount);
        registerDialog.add(new JLabel(""));
        registerDialog.add(registerButton);

        savingAccount.setSelected(true); // Default selection

        registerDialog.setVisible(true);
    }

    private void saveAccountInfo(String username, String password, String accountType) {
        String accountInfo = username + "," + password + "," + accountType;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/account.txt", true))) {
            writer.write(accountInfo);
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        // 如果创建的是 Current 账户，则在 currentInfo.txt 中写入用户名和初始余额
        if (accountType.equals("Current")) {
            writeCurrentAccountInfo(username);
        }
        //如果创建的是 Saving 账户，则在savingInfo.txt 中写入用户名、储蓄类型和初始余额
        else if (accountType.equals("Saving")) {
        	savingAccountSetup(username);
        }
    }

    private void writeCurrentAccountInfo(String username) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/currentInfo.txt", true))) {
            writer.write(username + ",0"); // 写入用户名和初始余额0
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void writeSavingAccountInfo(String username,String savingAmount) {
    	try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/savingInfo.txt", true))) {
            writer.write(username + ","+ savingAmount); // 写入用户名，存款量和存款类型
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    private void savingAccountSetup(String username) {
    	JDialog savingDialog = new JDialog(this,"Register",true);
    	savingDialog.setLayout(new GridLayout(2,5));
    	savingDialog.setSize(500,200);
    	savingDialog.setLocationRelativeTo(this);
    	
    	JTextField savingAmountField = new JTextField();
    	//JRadioButton oneWeek = new JRadioButton("1 week");
    	//JRadioButton halfmonth = new JRadioButton("half a month");
    	//JRadioButton oneMonth = new JRadioButton("one month");
    	//JRadioButton twoMonth = new JRadioButton("two months");
    	//JRadioButton oneSeason = new JRadioButton("one season");
    	//ButtonGroup saveTypeGroup = new ButtonGroup();
    	//saveTypeGroup.add(oneWeek);
    	//saveTypeGroup.add(halfmonth);
    	//saveTypeGroup.add(oneMonth);
    	//saveTypeGroup.add(twoMonth);
    	//saveTypeGroup.add(oneSeason);
    	JButton sureButton = new JButton("I'm Sure");
    	
    	sureButton.addActionListener(e ->{
    		String savingAmount = savingAmountField.getText();
			/*
			 * String savingType = ""; if(oneWeek.isSelected()==true) {//获取选中的储蓄类型
			 * savingType = "oneWeek"; }else if(halfmonth.isSelected()==true) { savingType =
			 * "halfMonth"; }else if(oneMonth.isSelected()==true) { savingType = "oneMonth";
			 * }else if(twoMonth.isSelected()==true) { savingType = "twoMonth"; }else {
			 * savingType = "oneSeason"; }
			 */
    	    writeSavingAccountInfo(username,savingAmount);
    	    setDefaultSavingTarget(username);
    	    JOptionPane.showMessageDialog(this, "Settled!");
    		savingDialog.dispose();
    	});   	
    	
    	savingDialog.add(new JLabel(""));
    	savingDialog.add(new JLabel("SavingAmount"));
    	savingDialog.add(savingAmountField);
    	savingDialog.add(new JLabel(""));
    	savingDialog.add(new JLabel(""));
    	/*savingDialog.add(oneWeek);
    	savingDialog.add(halfmonth);
    	savingDialog.add(oneMonth);
    	savingDialog.add(twoMonth);
    	savingDialog.add(oneSeason);*/
    	savingDialog.add(new JLabel(""));
    	savingDialog.add(new JLabel(""));
    	savingDialog.add(sureButton);
    	savingDialog.add(new JLabel(""));
    	savingDialog.add(new JLabel(""));
    	
    	//oneWeek.setSelected(true);
    	
    	savingDialog.setVisible(true);
    }
    
    private void setDefaultSavingTarget(String username) {
    	try(BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/targetInfo.txt",true))){
    		writer.write(username + "," + "NotSetYet");
    		writer.newLine();
    	}
    	catch(IOException ex) {
    		ex.printStackTrace();
    	}
    }

}
