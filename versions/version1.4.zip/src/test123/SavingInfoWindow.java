package test123;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SavingInfoWindow extends JFrame {
    private JTextField savingIdField;
    private String currentAccountId;

    public SavingInfoWindow(String currentAccountId) {
        this.currentAccountId = currentAccountId;
        setTitle("Saving Account Information");
        setSize(400, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        savingIdField = new JTextField(10);
        JButton nextButton = new JButton("Next");

        JLabel savingIdLabel = new JLabel("Saving ID:");
        inputPanel.add(savingIdLabel);
        inputPanel.add(savingIdField);
        inputPanel.add(nextButton);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        nextButton.addActionListener(e -> {
            String savingId = savingIdField.getText();
            if (!savingId.isEmpty()) {
                if (checkSavingId(savingId)) {
                    java.awt.EventQueue.invokeLater(() -> new DepositFromCurrent(currentAccountId, savingId).setVisible(true));
                    dispose(); // Close the current window
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Saving ID. Please enter a valid ID.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please enter a Saving ID.");
            }
        });

        add(mainPanel);
    }

    private boolean checkSavingId(String savingId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/savingInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 1 && parts[0].equals(savingId)) {
                    return true; // Saving ID exists
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false; // Saving ID does not exist
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SavingInfoWindow("currentAccountId").setVisible(true);
        });
    }
}
