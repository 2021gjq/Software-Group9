package test123;

import java.io.*;
import java.util.*;

public class Give {

    public static void giveReward(String userId, String reward) {
        String filePath = "D:/test123/currentInfo.txt";
        List<String> lines = new ArrayList<>();

        // 读取文件并更新用户余额
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userInfo = line.split(",");
                if (userInfo[0].equals(userId)) {
                    double currentBalance = Double.parseDouble(userInfo[1]);
                    double rewardAmount = Double.parseDouble(reward);
                    double newBalance = currentBalance + rewardAmount;
                    lines.add(userInfo[0] + "," + newBalance);
                } else {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 写回文件
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (String updatedLine : lines) {
                bw.write(updatedLine);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
