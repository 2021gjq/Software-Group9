package test123;

import java.io.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Current_Task extends JFrame{
    private static final String FILE_NAME = "D:/test123/taskInfo.txt";
    private List<Map<String, String>> categories = new ArrayList<>();
    private JTextField searchField;
    private JTextArea resultArea;

    public Current_Task () {
        setTitle("Current Task Page");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout());
        // 创建并添加搜索标签
        JLabel searchLabel = new JLabel("Please type in the ID");
        searchPanel.add(searchLabel);

        // 创建并添加搜索输入框
        searchField = new JTextField(20);
        searchPanel.add(searchField);

        // 创建并添加搜索按钮
        JButton searchButton = new JButton("Go");
        searchPanel.add(searchButton);

        // 添加搜索面板到窗口顶部
        add(searchPanel, BorderLayout.NORTH);

        // 创建并添加结果显示区域
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // 添加搜索按钮的事件监听器
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchId = searchField.getText();
                searchCategory(searchId);
            }
        });

        // 读取文件并解析数据
        readFile();
    }

    

        private void readFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            Map<String, String> category = new HashMap<>();
            int lineCount = 0;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue; // 跳过空行
                }
                if (line.equals(";")) {
                    // 遇到分号表示一个类别结束
                    if (!category.isEmpty()) {
                        categories.add(new HashMap<>(category));
                        category.clear();
                    }
                    lineCount = 0; // 重置行计数
                } else {
                    switch (lineCount) {
                        case 0:
                            category.put("id", line);
                            break;
                        case 1:
                            category.put("taskid", line);
                            break;
                        case 2:
                            category.put("reward", line);
                            break;
                        case 3:
                            category.put("taskname", line);
                            break;
                        case 4:
                            category.put("deadline", line);
                            break;
                        default:
                            // 处理异常情况
                            System.out.println("Unexpected line: " + line);
                            break;
                    }
                    lineCount++;
                }
            }

            // 添加最后一个类别，如果文件不以分号结尾
            if (!category.isEmpty()) {
                categories.add(new HashMap<>(category));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    private void searchCategory(String searchId) {
        boolean found = false;
        resultArea.setText("");
        for (Map<String, String> cat : categories) {
            if (cat.get("id").equals(searchId)) {
                found = true;
                resultArea.append("Category found:\n");
                resultArea.append("ID: " + cat.get("id") + "\n");
                resultArea.append("Task ID: " + cat.get("taskid") + "\n");
                resultArea.append("Reward: " + cat.get("reward") + "\n");
                resultArea.append("Task Name: " + cat.get("taskname") + "\n");
                resultArea.append("Deadline: " + cat.get("deadline") + "\n");
                resultArea.append("\n");
                break;
            }
        }

        if (!found) {
            resultArea.setText("The ID of" + searchId + "is not found.");
        }
    }

}
