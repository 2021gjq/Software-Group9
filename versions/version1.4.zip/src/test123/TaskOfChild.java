package test123;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TaskOfChild extends JFrame {
    private String childId;
    private JPanel taskListPanel;

    public TaskOfChild(String childId) {
        this.childId = childId;
        setTitle("Tasks of Child");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // 添加提示文本
        JLabel promptLabel = new JLabel("Please click on each completed task to give reward");
        promptLabel.setHorizontalAlignment(SwingConstants.CENTER);
        promptLabel.setVerticalAlignment(SwingConstants.CENTER);
        mainPanel.add(promptLabel, BorderLayout.NORTH);

        // 计算大按钮高度
        int buttonHeight = getHeight() / 4;

        // 创建任务列表面板
        taskListPanel = new JPanel();
        taskListPanel.setLayout(new BoxLayout(taskListPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(taskListPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // 显示孩子的任务
        displayChildTasks(childId);

        add(mainPanel);
    }

    private void displayChildTasks(String childId) {
        taskListPanel.removeAll();

        List<String> tasks = readTasksFromFile();

        boolean foundTasks = false;
        for (String task : tasks) {
            String[] taskInfo = task.split("\n");
            if (taskInfo.length == 5 && taskInfo[0].equals(childId)) {
                foundTasks = true;
                JButton taskButton = new JButton();
                taskButton.setPreferredSize(new Dimension(taskListPanel.getWidth(), getHeight() / 4)); // 设置按钮高度为界面的四分之一
                StringBuilder buttonText = new StringBuilder();
                buttonText.append("<html>");
                buttonText.append("<b>Task ID:</b> ").append(taskInfo[1]).append("<br>");
                buttonText.append("<b>Award:</b> ").append(taskInfo[2]).append("<br>");
                buttonText.append("<b>Task Name:</b> ").append(taskInfo[3]).append("<br>");
                buttonText.append("<b>Time Limit:</b> ").append(taskInfo[4]);
                buttonText.append("</html>");
                taskButton.setText(buttonText.toString());
                taskButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // 在这里添加点击任务后的处理逻辑
                        int choice = JOptionPane.showConfirmDialog(TaskOfChild.this, "Do you want to end this task?", "Confirmation", JOptionPane.YES_NO_OPTION);
                        if (choice == JOptionPane.YES_OPTION) {
                            // 发放奖励
                            Give.giveReward(childId, taskInfo[2]);
                            // 从任务列表中删除任务
                            TaskDeletion.deleteTask(childId, taskInfo[1]);
                            // 重新显示任务列表
                            displayChildTasks(childId);
                        }
                    }
                });
                taskListPanel.add(taskButton);
            }
        }

        if (!foundTasks) {
            JLabel noTasksLabel = new JLabel("This child has no tasks.");
            taskListPanel.add(noTasksLabel);
        }

        revalidate();
        repaint();
    }

    private List<String> readTasksFromFile() {
        List<String> tasks = new ArrayList<>();
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader("D:/test123/taskInfo.txt"))) {
            StringBuilder taskBuilder = new StringBuilder();
            while ((line = br.readLine()) != null) {
                taskBuilder.append(line).append("\n");
                if (line.endsWith(";")) {
                    tasks.add(taskBuilder.toString());
                    taskBuilder = new StringBuilder();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    public static void main(String[] args) {
        TaskOfChild taskOfChild = new TaskOfChild("childId");
        SwingUtilities.invokeLater(() -> taskOfChild.setVisible(true));
    }
}
