package test123;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TaskDeletion {
    private static final String FILE_PATH = "D:/test123/taskInfo.txt";

    public static void deleteTask(String childId, String taskId) {
        List<String> updatedTasks = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            StringBuilder taskBuilder = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                taskBuilder.append(line).append("\n");
                if (line.endsWith(";")) {
                    if (!taskBuilder.toString().startsWith(childId) || !taskBuilder.toString().contains(taskId)) {
                        updatedTasks.add(taskBuilder.toString());
                    }
                    taskBuilder = new StringBuilder();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String task : updatedTasks) {
                writer.write(task);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
