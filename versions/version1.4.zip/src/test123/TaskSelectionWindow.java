package test123;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TaskSelectionWindow extends JFrame {
    private String parentId;
    private String selectedChildId;

    public TaskSelectionWindow(String parentId) {
        this.parentId = parentId;
        setTitle("Task Selection Window");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridLayout(0, 1));

        JLabel infoLabel = new JLabel("Please choose your child", SwingConstants.CENTER);
        mainPanel.add(infoLabel);

        List<String> childIds = getChildIds(parentId);
        for (String childId : childIds) {
            JButton childButton = new JButton(childId);
            childButton.addActionListener(e -> {
                selectedChildId = childId;
                JOptionPane.showMessageDialog(this, "child: " + childId);
                dispose(); // Close the window after selecting a child
            });
            mainPanel.add(childButton);
        }

        add(mainPanel);
    }

    private List<String> getChildIds(String parentId) {
        List<String> childIds = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/parentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(parentId + ":")) {
                    // Parent's binding information found, extract child IDs
                    String[] bindings = line.substring(parentId.length() + 1).split(",");
                    for (String binding : bindings) {
                        childIds.add(binding);
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return childIds;
    }

    public String getSelectedChildId() {
        return selectedChildId;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TaskSelectionWindow("parentAccountId").setVisible(true));
    }
}
