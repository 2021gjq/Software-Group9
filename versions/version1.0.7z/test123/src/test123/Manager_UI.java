package test123;
import javax.swing.*;

public class Manager_UI {
	static void displayUI() {
        JOptionPane.showMessageDialog(null, "This is Manager UI");
    }
}
