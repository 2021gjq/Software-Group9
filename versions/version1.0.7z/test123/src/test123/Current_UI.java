package test123;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Current_UI extends JFrame {
    private JLabel balanceLabel;
    private JButton backButton, myTaskButton;
    private String accountId;

    public Current_UI(String accountId) {
        this.accountId = accountId;
        setTitle("Current Account Page");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        JPanel balancePanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // 面板用于放置balanceLabel

        backButton = new JButton("Back");
        myTaskButton = new JButton("My Task"); // 新增的按钮

        backButton.setPreferredSize(new Dimension(150, 50)); // 设置按钮大小
        myTaskButton.setPreferredSize(new Dimension(150, 50)); // 设置按钮大小

        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        myTaskButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        balanceLabel = new JLabel();

        // 读取用户余额并显示
        double balance = getAccountBalance(accountId);
        balanceLabel.setText("Balance: $" + balance);

        balancePanel.add(balanceLabel);

        buttonPanel.add(backButton);
        buttonPanel.add(myTaskButton);

        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        mainPanel.add(balancePanel, BorderLayout.NORTH); // 将balancePanel放在界面顶部

        backButton.addActionListener(e -> {
            // 关闭当前界面
            dispose();
            // 打开登录界面
            new UI().setVisible(true);
        });

        myTaskButton.addActionListener(e -> {
            // 处理 My Task 按钮的事件
            JOptionPane.showMessageDialog(this, "My Task Button Clicked!");
        });

        add(mainPanel);
    }

    private double getAccountBalance(String accountId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("D:/test123/currentInfo.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] accountInfo = line.split(",");
                if (accountInfo[0].equals(accountId)) {
                    return Double.parseDouble(accountInfo[1]); // 返回用户的余额
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return 0.0; // 如果未找到账户信息，则返回0.0
    }

    public static void displayUI(String accountId) {
        java.awt.EventQueue.invokeLater(() -> new Current_UI(accountId).setVisible(true));
    }
}
