package test123;
import javax.swing.*;

public class Saving_UI {
	static void displayUI() {
        JOptionPane.showMessageDialog(null, "This is Saving Account UI");
    }

}
