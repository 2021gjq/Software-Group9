package test123;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public abstract class Account {
    protected String accountId;
    protected double balance;

    public Account(String accountId, double balance) {
        this.accountId = accountId;
        this.balance = balance;
    }

    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);

    protected void writeCurrentAccountInfo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:/test123/currentInfo.txt", true))) {
            writer.write(accountId + ",0"); // 写入账户ID和初始余额0
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
