package test123;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Saving_UI extends JFrame {
	//static void displayUI() {
        //JOptionPane.showMessageDialog(null, "This is Saving Account UI");
    //}测试用
	private JLabel savingLabel,expireLabel,targetLabel;
	private JButton backButton, targetButton;
	private String accountId;
	
	public Saving_UI(String accountId) {
		this.accountId = accountId;
		setTitle("Saving Account Page");
		setSize(400 , 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		initComponents();
	}
	private void initComponents() {
		JPanel mainPanel = new JPanel(new GridLayout(1,2));
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new GridLayout(2,1));
		JPanel savingPanel = new JPanel(new GridLayout(3,1));//两个面板
		
		targetButton = new JButton("setTarget!");
		backButton = new JButton("Back");
		
		savingLabel = new JLabel();
		
		// 读取用户存款量
		double saving = getAccountSaving(accountId);
		double expire = getAccountExpire(accountId);
		//System.out.println(expire);
		String target = getSavingTarget(accountId);
		
		savingLabel.setText("You saved: $" + saving + "\nYou will get : $"+ expire + "\nYour target is : $" + target);
		//expireLabel.setText("You will get: $" + expire);
		//targetLabel.setText("Your target is: $" + target);
		//此处不知为何，添加别的JLabel会导致窗口打不开，先用一个将就一下
		savingPanel.add(savingLabel);
		//savingPanel.add(expireLabel);
		//savingPanel.add(targetLabel);
		
		buttonPanel.add(backButton);
		buttonPanel.add(targetButton);
		mainPanel.add(buttonPanel,BorderLayout.SOUTH);
		mainPanel.add(savingPanel, BorderLayout.NORTH);
		
		targetButton.addActionListener(e ->{
			createTargetDialog(accountId);//打开设置存款目标的界面
		});
		
		backButton.addActionListener(e ->{
			//关闭当前界面
			dispose();
			//打开登录界面
			new UI().setVisible(true);
		});
		
		add(mainPanel);
	}
	
	private void createTargetDialog(String accountId) {//保存存款目标的界面
		JDialog targetDialog = new JDialog(this, "Target", true);
		targetDialog.setLayout(new GridLayout(3,2));
		targetDialog.setSize(300,150);
		targetDialog.setLocationRelativeTo(this);
		
		JLabel frontTarget = new JLabel("Your target is: ");
		JTextField targetField = new JTextField();
		JButton insureButton = new JButton("sure");
		JButton cancleButton = new JButton("cancle");
		
		insureButton.addActionListener(e->{
			String target = targetField.getText();
			resetSavingTarget(accountId, target);
			JOptionPane.showMessageDialog(this, "Settled!");
			targetDialog.dispose();
		});
		cancleButton.addActionListener(e->{
			targetDialog.dispose();
		});
		
		targetDialog.add(frontTarget);
		targetDialog.add(targetField);
		targetDialog.add(insureButton);
		targetDialog.add(cancleButton);
		
		targetDialog.setVisible(true);
		
	}
	
	//可以把增加存款量的函数写在此处
	
	private void resetSavingTarget(String accountId, String target) {//设置存款目标的方法
		try {
			RandomAccessFile raf = new RandomAccessFile("D:/code/JavaCode/test123/targetInfo.txt","rw");
			String line;
			line=raf.readLine();
			if(line.contains(accountId)) {
				String[] split = line.split(accountId);
				//System.out.println(split[0]+"+"+split[1]);
				raf.seek(split[0].length());
				raf.writeBytes(accountId + "," + target + "      ");
			}
			raf.close();
		} catch(IOException ex){
			ex.printStackTrace();
		}
	}
	
	private double getAccountSaving(String accountId) {//读取存款量的方法
		try(BufferedReader reader = new BufferedReader(new FileReader("D:/code/JavaCode/test123/savingInfo.txt"))){
			String line;
			while ((line = reader.readLine()) != null) {
				String[] accountInfo = line.split(",");
				if (accountInfo[0].equals(accountId)) {
					//System.out.println(accountInfo[1]);
					return Double.parseDouble(accountInfo[1]);
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return 0.0;
	}
	
	private String getSavingTarget(String accountId) {//读取存款目标的方法
		try(BufferedReader reader = new BufferedReader(new FileReader("D:/code/JavaCode/test123/targetInfo.txt"))){
			String line;
			while((line = reader.readLine()) != null) {
				String[] targetInfo = line.split(",");
				if (targetInfo[0].equals(accountId)) {
					//System.out.println(targetInfo[1]);
					return targetInfo[1];
				}
			}
		} catch(IOException ex) {
			ex.printStackTrace();
		}
		return "";
	}
	
	private double getAccountExpire(String accountId) {//计算最终收益的方法
		double expire = 0;
		try(BufferedReader reader = new BufferedReader(new FileReader("D:/code/JavaCode/test123/savingInfo.txt"))){
			String line;
			while((line = reader.readLine()) != null) {
				String[] accountInfo = line.split(",");
				if (accountInfo[0].equals(accountId)) {
					double savingAmount = Double.parseDouble(accountInfo[1]);
					//System.out.println(accountInfo[1]);
					//计算收益
					if(accountInfo[2].equals("oneWeek") == true) {
						expire = 1.1 * savingAmount;
					} else if(accountInfo[2].equals("halfMonth") == true) {
						expire = 1.12 * savingAmount;
					} else if(accountInfo[2].equals("oneMonth") == true) {
						expire = 1.14 * savingAmount;
					} else if (accountInfo[2].equals("twoMonth") == true) {
						expire = 1.16 * savingAmount;
					} else if (accountInfo[2].equals("oneSeason") == true) {
						expire = 1.18 * savingAmount;
					} else {
						JOptionPane.showMessageDialog(this, "Unown saving type");
						return 0;
					}
					//switch(savingType) {
					//case "oneWeek":
						//return 1.1 * savingAmount;						
					//case "halfMonth":
						//return 1.12 * savingAmount;
					//case "oneMonth":
						//return 1.14 * savingAmount;						
					//case "twoMonth":
						//return 1.16* savingAmount;						
					//case "oneSeason":
						//return 1.18 * savingAmount;
					//default:
						//JOptionPane.showMessageDialog(this, "Unown saving type");
				}
			}
		} catch(IOException ex){
			ex.printStackTrace();
		}
		//System.out.println(expire);
		return expire;
	}
	
	public static void displayUI(String accountId) {
		java.awt.EventQueue.invokeLater(() -> new Saving_UI(accountId).setVisible(true));
	}

}
