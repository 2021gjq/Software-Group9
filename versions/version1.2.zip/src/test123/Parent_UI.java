package test123;
import javax.swing.*;

public class Parent_UI {
	static void displayUI() {
        JOptionPane.showMessageDialog(null, "This is Parent UI");
    }

}
